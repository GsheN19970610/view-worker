package com.qf.data.view.core.model.dto;

public class WorkerDTO {
}
