package com.qf.data.view.core.model.constant;

public interface CookieConstant {

    String LOGIN_TOKEN = "login_token";


}
