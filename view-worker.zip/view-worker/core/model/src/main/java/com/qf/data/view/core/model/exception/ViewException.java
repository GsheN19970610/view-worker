package com.qf.data.view.core.model.exception;

public class ViewException extends RuntimeException{

    public ViewException(String message) {
        super(message);
    }


}
