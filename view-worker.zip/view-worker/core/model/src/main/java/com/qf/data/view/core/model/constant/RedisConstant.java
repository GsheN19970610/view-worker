package com.qf.data.view.core.model.constant;

public interface RedisConstant {
    String WORKER_SIGN_PRE = "worker:sign";


}
