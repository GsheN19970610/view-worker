package com.qf.data.view.core.model.response;

import lombok.Data;

@Data
public class WorkerResponse {

    private Long id;

    private String name;

    private Boolean gender;

    private Integer age;

    private Boolean workType;

    private Boolean status;

    private Boolean flag;



}
