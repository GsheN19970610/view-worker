package com.qf.data.view.core.model.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class WorkerSelectRequest implements Serializable {

    private Long id;

}
