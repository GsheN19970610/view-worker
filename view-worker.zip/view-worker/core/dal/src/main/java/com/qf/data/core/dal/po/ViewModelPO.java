package com.qf.data.core.dal.po;

import com.qf.data.core.dal.po.base.BaseModel;

public class ViewModelPO extends BaseModel {
}
