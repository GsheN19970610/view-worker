package com.qf.data.view.core.service.view;

public interface ViewService {

}
