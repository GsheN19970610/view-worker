package com.qf.data.view.core.service.impl;

import com.qf.data.view.core.service.view.ViewService;


public class ViewServiceImpl implements ViewService {

    //插入数据：Mapper  注入view-core-dal里的viewMapper,通过Mapper来插入数据
}
