package com.qf.bigdata.view.web.controller.api;

import com.qf.bigdata.view.web.controller.base.BaseController;

public class ViewAPIController extends BaseController {
    //controller->service 数据传输 数据传输对象： viewModelRequest对象
}
