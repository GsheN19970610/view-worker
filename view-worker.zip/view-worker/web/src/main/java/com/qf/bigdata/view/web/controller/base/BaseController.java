package com.qf.bigdata.view.web.controller.base;


public abstract class BaseController {

}
