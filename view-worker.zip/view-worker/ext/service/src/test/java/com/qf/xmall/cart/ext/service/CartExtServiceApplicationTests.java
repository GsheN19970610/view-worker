package com.qf.bigdata.view.ext.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class viewExtServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
