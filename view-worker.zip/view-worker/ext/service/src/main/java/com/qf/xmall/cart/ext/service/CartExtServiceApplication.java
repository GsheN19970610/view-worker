package com.qf.bigdata.view.ext.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class viewExtServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(viewExtServiceApplication.class, args);
    }

}
