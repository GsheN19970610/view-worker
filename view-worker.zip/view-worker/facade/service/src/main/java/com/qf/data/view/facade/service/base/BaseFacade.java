
package com.qf.data.view.facade.service.base;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Facade Base
 */
public class BaseFacade {

	protected Logger log = LoggerFactory.getLogger(this.getClass());



	/**
	 * 包装ERROR结果
	 */



	/**
	 * 包装正常返回结果
	 *
	 */


	/**
	 * 包装结果
	 *
	 */

	/**
	 * 判断返回是否成功
	 *
	 */

}
