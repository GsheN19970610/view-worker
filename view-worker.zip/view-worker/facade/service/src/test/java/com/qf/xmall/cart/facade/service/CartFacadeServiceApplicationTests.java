package com.qf.bigdata.view.facade.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class viewFacadeServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
