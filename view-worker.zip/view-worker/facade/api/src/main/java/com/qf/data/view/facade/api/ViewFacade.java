package com.qf.data.view.facade.api;

public interface ViewFacade {


}
