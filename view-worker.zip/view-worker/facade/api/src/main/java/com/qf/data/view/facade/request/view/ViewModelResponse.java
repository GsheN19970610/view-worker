package com.qf.data.view.facade.request.view;

import com.qf.data.view.facade.model.view.BaseModel;

public class ViewModelResponse extends BaseModel {
}
