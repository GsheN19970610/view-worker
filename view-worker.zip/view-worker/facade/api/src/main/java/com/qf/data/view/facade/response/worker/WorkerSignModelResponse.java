package com.qf.data.view.facade.response.worker;

import lombok.Data;

@Data
public class WorkerSignModelResponse {



}
